/**
 * ServiceManagement App Database Utility. 
 * This Util has all support functions for DB operations, uses SQL driver supported classes & utilities for persistence 
 * Copyright Enser, Inc
 * 
 */

//global variables
var mysql = require('mysql');
var helper = require('./ServiceHelper');

/**
 * Create a new Connection instance.
 * @param {object|string} config Configuration or connection string for new MySQL connection
 * @return {Connection} A new MySQL connection
 * @public
 */
exports.getDBConnection = function getDBConnection() {
  	//console.log(' DBUtils.getDBConnection >>>>>>');
    return getEnserConnection();
};

/**
 * Closes an existing connection.
 * @param {object|string} an active connection object
 * @return {boolean} Whether connection is closed or not
 * @public
 */
exports.closeDBConnection = function closeDBConnection(connection) {
  //console.log(' DBUtils.closeDBConnection >>>>>>');
  closeConnection();
  return true;
};

/**
 * Debugs class instantiation.
 * @param {none} 
 * @return {boolean} Function could be called
 * @public
 */
exports.checkClassAccess = function checkClassAccess() {
  //console.log(' DBUtils.checkClassAccess new >>>>>>');
  return true;
};

function getEnserConnection() {
	//console.log(' DBUtils.getLogosConnection >>>>>>');
	var connection = mysql.createConnection({
        host     : 'ServiceManagement.cc99l18g9gw3.us-east-1.rds.amazonaws.com',
        port      : '3306',
        user     : 'smadmin', //yet to encrypt password and read from properties
        password : 'test123', //yet to encrypt password and read from properties
        database: 'ServiceManagement'
    });    
    return connection;
}

function closeConnection(connection) {
	connection.end();
}

function isEmpty(obj) {
    for (var key in obj) {
        if(obj.hasOwnProperty(key))
            return false;
    }
    return true;
}