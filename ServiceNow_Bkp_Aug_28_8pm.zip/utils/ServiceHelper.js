/**
 * ServiceManagement Application Utils. 
 * All global re-usable/utility functions listed here. Class could be expanded to cover my utils
 * JSON parsing is main 
 * Copyright Enser, Inc
 * 
 */

var aws = require('aws-sdk');
var request = require('request');
var https = require('https');
var dbUtil = require('./DBUtils');
var querystring = require('querystring')

/**
 * Create a new build response.
 * @param {object} [values]Session Attributes to use in add in response object
 * @param {object} Speech output
 * 
 * @public
 */
exports.buildResponse = function buildResponse(sessionAttributes, speechletResponse) {
	console.log(' ServiceHelper.buildResponse >>>>>>');
	return {
        version: '1.0',
        sessionAttributes,
        response: speechletResponse,
    };
    
};

/**
 * Returns APP ID for Service Management.
 * @param {object} none
 * @return {string} Context APP ID
 * 
 * @public
 */
exports.getAppLinkName = function getAppLinkName(event) {
	console.log(' ServiceHelper.buildResponse >>>>>>');
	var appId = 'amzn1.ask.skill.cfcd4634-cd36-4617-8dc5-f0fc13d1475f';
    //appId = getAccountLinkName(event);
	return appId;
    
};

/**
 * Returns APP ID for Service Management.
 * @param {object} none
 * @return {string} Context APP ID
 * 
 * @public
 */
exports.processNameIntent = function processNameIntent(userName, profileId, hasProfile, profileComplete, session, callback) {
	console.log(' ServiceHelper.processNameIntent >>>>>>');
    processNameIntentResponse(userName, profileId, hasProfile, profileComplete, session, callback);
};

/**
 * Returns APP ID for Service Management.
 * @param {object} none
 * @return {string} Context APP ID
 * 
 * @public
 */
exports.processSessionEnd = function processSessionEnd(callback) {
	console.log(' ServiceHelper.processSessionEnd >>>>>>');
    handleSessionEndRequest(callback);
};


/**
 * Provides a speech response to Alexa using JSON format.
 * @param {object|string} Title of the Speech card
 * @param {object|string} Speech output text 
 * @param {object|string} To prompt speech out text
 * @param {object|string} Whether session to be end or not
 * @return {object} A JSON object constructed with speech out text
 * @public
 */
exports.buildSpeechletResponse = function buildSpeechletResponse(title, output, repromptText, shouldEndSession) {
  	console.log(' ServiceHelper.buildSpeechletResponse >>>>>>');
  	return {
        outputSpeech: {
            type: 'PlainText',
            text: output,
        },
        card: {
            type: 'Simple',
            title: `${title}`,
            content: `${output}`,
        },
        reprompt: {
            outputSpeech: {
                type: 'PlainText',
                text: repromptText,
            },
        },
        shouldEndSession,
    };
};

/**
 * Method to create an App Link to from a new request.
 * @param {object|string} Event
 * @param {object|string} Context object 
 * @param {object|string} Request
 * @param {object|string} App ID
 * @return {object} Applink ID once successfully created or ERROR
 * @public
 */
exports.createApplink = function createApplink(event, context, request, appId) {
  	console.log(' ServiceHelper.createApplink >>>>>>');
  	//TODO: implement code to create an App link from caller
};

/**
 * Debugs class instantiation.
 * @param {none} 
 * @return {boolean} Function could be called
 * @public
 */
exports.checkClassAccess = function checkClassAccess() {
  	console.log(' ServiceHelper.checkClassAccess >>>>>>');
  	return true;
};

/**
 * Debugs class instantiation.
 * @param {none} 
 * @return {boolean} Function could be called
 * @public
 */
exports.displayWelcomeMsg = function displayWelcomeMsg(accountEmail, session, callback) {
  	console.log(' ServiceHelper.displayWelcomeMsg >>>>>>'+accountEmail);
  	processWelcomeResponse(accountEmail, session, callback);
};

exports.displayUnknownIntent = function displayUnknownIntent(accountid, session, callback) {
  	//console.log(' ServiceHelper.displayUnknownIntent >>>>>>'+accountid);
  	displayUnknownContext(accountid, session, callback);
};

exports.processUserReponse = function processUserReponse(event, context, intent, session, callback) {
  	//console.log(' ServiceHelper.processUserReponse >>>>>>');
  	processIntent(event, context, intent, session, callback);
};

exports.processQnAResponse = function processQnAResponse(qnaObj, session, callback, retUser) {
  	//console.log(' ServiceHelper.processQnAResponse >>>>>>'+retUser);
  	processResponse(qnaObj, session, callback, retUser);
};

exports.processErrResponse= function processErrResponse(errorText, processor, session, callback) {
  	//console.log(' ServiceHelper.processErrResponse >>>>>>');
  	processErrorResponse(errorText, processor, session, callback);
};

exports.gotoMainMenu= function gotoMainMenu(speechOutput, session, callback) {
  	//console.log(' ServiceHelper.processErrResponse >>>>>>');
  	 processMenuResponse(speechOutput, session, callback);
};


function getLinkedAccountEmail(event, request, session, accountId, callback) {
    console.log(" Getting Account Linked Email ");
	
	var amznProfileURL = 'https://api.amazon.com/user/profile?access_token=';
    amznProfileURL += event.session.user.accessToken;
    
    request(amznProfileURL, function(error, response, body) {
 	    var respBody = "";
 	    if (!error && response.statusCode == 200) {
    	    respBody = JSON.parse(body);
    	    console.log('Email from Amazon: ' + respBody.email);
	    } else {
	    	console.log('Email read Error: ' + error);
	    }
	    dbUtil.getAccountIdFromEmail(respBody.email, session, callback);
	});
}

function displayUnknownContext(accountid, session, callback ) {
    console.log(' ServiceHelper.displayUnknownContext >>>>>>'+accountid);
    // If we wanted to initialize the session to have some attributes we could add those here.
    var sessionAttributes = session.attributes;
    
    var cardTitle = 'ServiceManagement App';

    var speechOutput = 'Not sure I understand your intent, please say help to hear options!';

    var repromptText = 'What can I help you with?';
    var shouldEndSession = false;
    
    callback(session.attributes, buildSpeechResponse(cardTitle, speechOutput, repromptText, shouldEndSession));
}

function buildSpeechResponse(title, output, repromptText, shouldEndSession) {
  	console.log(' ServiceHelper.buildSpeechResponse >>>>>>');
  	return {
        outputSpeech: {
            type: 'PlainText',
            text: output,
        },
        card: {
            type: 'Simple',
            title: `${title}`,
            content: `${output}`,
        },
        reprompt: {
            outputSpeech: {
                type: 'PlainText',
                text: repromptText,
            },
        },
        shouldEndSession,
    };
}

function processIntent(event, context, intentRequest, session, callback) {
 
    var intent = intentRequest.intent;
    var intentName = intentRequest.intent.name;
    
    var sessionAttributes = session.attributes; 
    var accountId = sessionAttributes.accountid;
    var userName = sessionAttributes.logosname;
    var retUser = sessionAttributes.retUser;
    
    var slotValue = "";
    console.log('ProcessIntent: Intent  called >>>>>>  '+intentName+ ' CurrentProcessor: '+ session.attributes.currentProcessor);

    if (intentName == 'LaunchIntent') {
    	//Process Generic values if selected from existing
    	slotValue = intent.slots.Answer.value;
    	//console.log(' processIntent: Intent  called >>>>>>  '+intentName+' the slot value is >>>>> '+slotValue);
    	processUserGenericInteraction(event, intentName, session, callback);
    }
	else if (intentName == 'AMAZON.HelpIntent') {        
	    //helpRequest(intent, session, callback);    
    }    
    else if (intentName == 'AMAZON.CancelIntent')  {        
	    //quitRequest(intent, session, callback);  
    }
    else if (intentName == 'AMAZON.YesIntent')  {   
    	//console.log(' AMAZON.YesIntent: Intent  parameter check >>>>>>  '+retUser);
    	slotValue = "yes";
    	processAnswerIntent(event, intentName, slotValue, accountId, session, callback); 
    }
    else if (intentName == 'AMAZON.NoIntent')  {   
    	//console.log(' AMAZON.NoIntent: Intent  called >>>>>>  '+intentName);
    	slotValue = "no";
        //user choose to say NO, send him to the main menu 
        processAnswerIntent(event, intentName, slotValue, accountId, session, callback); 
    }
	else if (intentName == 'MainMenuIntent') {
		console.log(' MainMenuIntent: Intent  called >>>>>>  '+intentName+' the slot value is >>>>> '+slotValue);
		processAnswerIntent(event, intentName, slotValue, accountId, session, callback); 
    }
    else if (intentName == 'CreateIncidentIntent')  {    
    	console.log(' CreateIncidentIntent: Intent  called >>>>>>  '+intentName+' the slot value is >>>>> '+slotValue);
        processAnswerIntent(event, intentName, slotValue, accountId, session, callback); 
    }
    else if (intentName == 'AnswerIntent')  {        
		if (slotValue == ""){
			slotValue = intent.slots.Answer.value;		
		}
    	console.log(' processIntent: Intent  called >>>>>>  '+intentName+' the slot value is >>>>> '+slotValue);
        processAnswerIntent(event, intentName, slotValue, accountId, session, callback); 
    }
	else {
		var errorText = "This is not a valid menu option.  Please try again.";
		processErrorResponse(errorText, 5, session, callback);
        //could be user saying something out of a custom intent, process based on Current processor
        //processUserGenericInteraction(event, intent, session, callback);
    }
}

function processWelcomeResponse(accountEmail, session, callback ) {
    console.log(' ServiceHelper.processWelcomeResponse >>>>>>'+accountEmail);
    // If we wanted to initialize the session to have some attributes we could add those here.

	var qnObj = '';
    var sessionAttributes = {
    		'currentProcessor':1,
    		'accountEmail':accountEmail,
    		'empId':0,
    		'name':'',
    		'qnaObj':qnObj
    };
    
	session.attributes = sessionAttributes;
    
    var cardTitle = 'Alcor Service Management App';

    var speechOutput = 'Welcome to Alcor Incident Management. Please provide your Employee Number.';

    var repromptText = 'Please provide your Employee ID';
    var shouldEndSession = false;
    
    callback(session.attributes, buildSpeechResponse(cardTitle, speechOutput, repromptText, shouldEndSession));

}

function processAnswerIntent(event, intentName, slotValue, accountId, session, callback) {
    // User Response processor
    console.log(' ServiceHelper:processAnswerIntent >>>>>>'+slotValue);
    var qnaObj = {};
    //set session attributes
    var sessionAttributes = session.attributes;
    var currentProcessor = sessionAttributes.currentProcessor;
    
    console.log(' ServiceHelper:processAnswerIntent >>>>>>'+currentProcessor);
    
    switch(currentProcessor) {
    case 1:
		session.attributes.empId = slotValue;	
        responseHelp(slotValue, session, callback);
        break;
    case 2:
        //Process User Response
        processResponse(event, intentName, slotValue, accountId, session, callback)
        break;
    case 3:
       	//Initiate Incident Creation
       	processResponseForIncident(event, intentName, slotValue, accountId, session, callback);
        break;
    case 4:
       	//Process 4
        break;
    case 5:
		var errorText = "This is not a valid menu option.  Please try again.";
		processErrorResponse(errorText, 5, session, callback);	
        break;
    default:
        processUserGenericInteraction (session, callback);
	}
}

function responseHelp(slotValue, session, callback) {
    console.log(' ServiceHelper.responseHelp >>>>>>'+slotValue);
    var empName = "Magic";
    
    var cardTitle = 'Alcor Service Management App';
    if (slotValue == '200') {
    	empName = "John Spirko";
    }
    
    session.attributes.name = empName;
    session.attributes.currentProcessor = 2;

    var speechOutput = 'Hello Mr. '+empName+'! Welcome to Alcor Service Management App. How can I help you today? Say Menu for more options!';

    var repromptText = 'Say Main Menu';
    var shouldEndSession = false;
    
    callback(session.attributes, buildSpeechResponse(cardTitle, speechOutput, repromptText, shouldEndSession));

}

function handleSessionEndRequest(callback) {
    var cardTitle = 'Session Ended';
    var speechOutput = 'Have a nice day!';
    // Setting this to true ends the session and exits the skill.
    var shouldEndSession = true;

    callback({}, buildSpeechResponse(cardTitle, speechOutput, null, shouldEndSession));
}

function processWelcom(session, callback) {
	//TODO: Implement main menu options here
}

function processUserGenericInteraction (session, callback) {
    //TODO: Implementation
    console.log(' ServiceHelper.processUserInteraction >>>>>>');
    //set session attributes
    var sessionAttributes = session.attributes;
    sessionAttributes.currentProcessor = '6';
    
    var cardTitle = 'Open Menu Options';

    var speechOutput = 'Sorry, Couldnt get your response. Please say help to hear menu options';

    var repromptText = 'Unknown context';
    var shouldEndSession = false;
    session.attributes = sessionAttributes;
    callback(session.attributes, buildSpeechResponse(cardTitle, speechOutput, repromptText, shouldEndSession));
}

function processResponse(event, intentName, slotValue, accountId, session, callback) {
	console.log('ServiceHelper.processResponse : CALLED>>> '+intentName);
	
    var sessionAttributes = session.attributes;
    var isProcessed = false;
    var isComplete = true;
    
	var speechOutput = "";
	
	if (intentName == 'MainMenuIntent') {
		speechOutput = 'Hello '+sessionAttributes.name+ '. "," Welcome to the ServiceNow main menu. Please choose one of the following options. ';
    	speechOutput = speechOutput+ ' Create Incident. '+
					' Create Change. '+
					' Create Critical Alert. '+
					' Request a New VM on Cloud. '+
					' Request Password Reset. '+
					' Request Azure Access. ';
    	var cardTitle = 'Processing User Response';

		var repromptText = 'Say Save Incident';
		var shouldEndSession = false;
		var qnaObj = processIncidentCreation(event, intentName, slotValue, accountId, session, callback);
		session.attributes.qnaObj = qnaObj;
	
		console.log(' ServiceHelper.processResponse >>>>>>: output text is '+speechOutput);
		session.attributes.currentProcessor = 3;
		callback(session.attributes, buildSpeechResponse(cardTitle, speechOutput, repromptText, shouldEndSession));
	}  else {
		processResponseForIncident(event, intentName, slotValue, accountId, session, callback);
	}
}

function processIncidentCreation(event, intentName, slotValue, accountId, session, callback){
	  
  console.log('ServiceHelper.processIncidentCreation : CALLED>>> '+slotValue);
  
  var sessionAttributes = session.attributes;
  var isProcessed = false;
  var isComplete = true;
  
  var eventQnaObj = {};
  var eventObjArr = [];
  
	eventQnaObj = {
		"questionId": 100,
		"question": "Incident Creation. Please provide Short Description",
		"answer": "",
		"processed": false,
		"errResponse":'Invalid Short Description. Please provide valid Short Description.'
	};
	eventObjArr.push(eventQnaObj);
	
	eventQnaObj = {
		"questionId": 200,
		"question": "Please provide Category",
		"answer": "",
		"processed": false,
		"errResponse":'Invalid Category. Please provide valid Category.'
	};
	eventObjArr.push(eventQnaObj);
	
	
	eventQnaObj = {
		"questionId": 300,
		"question": "Please provide Sub Category.",
		"answer": "",
		"processed": false,
		"errResponse":'Invalid Sub Category. Please provide Sub Category.'
	};
	eventObjArr.push(eventQnaObj);
	
	
	eventQnaObj = {
		"questionId": 400,
		"question": "Provide Impact.",
		"answer": "",
		"processed": false,
		"errResponse":'Invalid Impact. Please provide Impact.'
	};
	eventObjArr.push(eventQnaObj);
	
	eventQnaObj = {
		"questionId": 500,
		"question": "Provide Urgency.",
		"answer": "",
		"processed": false,
		"errResponse":'Invalid Urgency. Please provide valid Urgency.'
	};
	eventObjArr.push(eventQnaObj);

	return eventObjArr;
}

function processResponseForIncident(event, intentName, slotValue, accountId, session, callback) {
	console.log('ServiceHelper.processResponseForIncident : CALLED>>> '+slotValue);
	
	//loop qnaObj for each question to discuss. Once done, trigger Incident Creation action to ServiceNow instance
	var isComplete = true;
	var incNbr = 0;
	var speechOutput = "";
	var qnaObj = session.attributes.qnaObj;
	session.attributes.currentProcessor = 3;
	
	console.log('ServiceHelper.processResponseForIncident : QnA Object form Session length >>> '+qnaObj.length);
	
	for (var quest in qnaObj) {
		console.log('ServiceHelper.processResponseForIncident : Quest processed is '+qnaObj[quest].processed+' and answer is '+qnaObj[quest].answer+' and slot value is '+slotValue);
		isComplete = true;
		if (!qnaObj[quest].processed) {
		 console.log('ServiceHelper.processResponseForIncident : in IF '+qnaObj[quest].processed);
			speechOutput = qnaObj[quest].question;
			qnaObj[quest].processed = true;
			isComplete = false;
			break;
		} else if (qnaObj[quest].answer == '') {
		console.log('ServiceHelper.processResponseForIncident : in ELSE IF '+qnaObj[quest].processed+' and answer is '+qnaObj[quest].answer);
			qnaObj[quest].answer = slotValue;
			//isComplete = false;
			continue;
		} 
	}
	
	console.log('ServiceHelper.processResponseForIncident : is COMPLETE is '+isComplete);
	
	if (isComplete) {
		//TODO: Initiate WebService call to servicenow instance
		session.attributes.currentProcessor = 4;
		incNbr = getIncidentNumber(session, callback);
	}  else {
		var cardTitle = 'Incident Creation';

		var repromptText = 'Incident Creating';
		var shouldEndSession = false;
		session.attributes.qnaObj = qnaObj;
	
		console.log('ServiceHelper.processResponseForIncident>: output text is '+speechOutput);
  
		callback(session.attributes, buildSpeechResponse(cardTitle, speechOutput, repromptText, shouldEndSession));
	}
}

function getIncidentNumber(session, callback) {
 	console.log('ServiceHelper.getIncidentNumber : WebRequest initiated ');
 
 	var qnaObj = session.attributes.qnaObj;
 	console.log('ServiceHelper.getIncidentNumber : The QNA Object Length '+qnaObj.length);
 	
    let shouldEndSession = false;
    let repromptText = null;
    let speechOutput = '';
    let cardTitle = '';
    
    var jsonObject = JSON.stringify({"short_description":"Test","description":"Test Desc","category":"Test Cat","contact_type":"alert","subcategory":"Test Sub","impact":"1","urgency":"1"});
    
    var options = {
	   uri: 'https://alcordemo7.service-now.com/api/alsoi/create_alexa_incident',
	   port: 443,
	   method: 'POST',
	   json: true,
	   // authentication headers
	   headers: {
		  'Authorization': 'Basic ' + new Buffer('ajay.kanth' + ':' + 'T0ySt0ry').toString('base64'),
		  'Content-Type': 'application/json',
		  'Content-Length' : Buffer.byteLength(jsonObject, 'utf8')
	   }   
	};
	
	var reqPost = request(options, function (err, res, body) {
	  if (err) {
		console.log("ServiceHelper.getIncidentNumber -- Got error: " + err);
	  } else {
	  		console.log("ServiceHelper.getIncidentNumber --  Body :"+ body.result.IncidentNumber);
	  		var cardTitle = 'Incident Creation';

			var repromptText = 'Incident Creating';
			var shouldEndSession = false;
			var speechOutput = "A new Incident "+body.result.IncidentNumber+" created for you!";
			console.log('ServiceHelper.processResponseForIncident>: output text is '+speechOutput);
			callback(session.attributes, buildSpeechResponse(cardTitle, speechOutput, repromptText, shouldEndSession));
	  	}

	});
	
	// write the json data
	reqPost.write(jsonObject);
	reqPost.end();
	reqPost.on('error', function(e) {
		console.error(e);
	});
	
 }
	
/*	
	https.request(options, function(res){
	   var body = "";
	   res.on('data', function(data) {
		  body += data;
	   });
	   
	   res.on('end', function() {
		//here we have the full response, html or json object
		  console.log('ServiceHelper.getIncidentNumber Body '+body);
	   })
	   
	   res.on('error', function(e) {
		  onsole.log("ServiceHelper.getIncidentNumber -- Got error: " + e.message);
	   });
	});
	}
	*/
 /*
    let url = "https://alcordemo7.service-now.com/api/alsoi/create_alexa_incident";
 
    getWebRequest(options, function webResonseCallback(err, data) {
        if (err) {
            speechOutput = "Sorry I couldn't connect to the server: " + err;
            console.log('ServiceHelper.getIncidentNumber : ERRRORRR '+err);
        } else {
            //something like this
            const incNbr = data.IncidentNumber;
            var cardTitle = 'Incident Created';
    		var repromptText = 'Incident Created';
    		var shouldEndSession = false;
    		
            speechOutput = 'A New Incident is created on Alcor Instance. '+incNbr;            
            callback(session.attributes, buildSpeechResponse(cardTitle, speechOutput, repromptText, shouldEndSession));                 
        }
    });
}
*/

function getWebRequest(url,doWebRequestCallBack) {
    console.log('ServiceHelper.getWebRequest : WebRequest initiated ');
   
    https.get(url, function (res) {
        var webResponseString = '';
        console.log('ServiceHelper.getWebRequest : Status Code is '+res.statusCode);
 
        if (res.statusCode != 200) {
            doWebRequestCallBack(new Error("Non 200 Response"));
        }
 
        res.on('data', function (data) {
            webResponseString += data;
        });
 
        res.on('end', function () {
            //console.log('Got some data: '+ webResponseString);            
            var webResponseObject = JSON.parse(webResponseString);            
            if (webResponseObject.error) {
                //console.log("Web error: " + webResponseObject.error.message);
                doWebRequestCallBack(new Error(webResponseObject.error.message));
            } else {
                //console.log("web success");
                doWebRequestCallBack(null, webResponseObject);
            }
        });
    }).on('error', function (e) {
        //console.log("Communications error: " + e.message);
        doWebRequestCallBack(new Error(e.message));
    });
}


function processErrorResponse(errorText, processor, session, callback) {
	//console.log('ServiceHelper.processErrorResponse : CALLED>>> ');
    
    var cardTitle = 'User Input Error';

    var repromptText = 'Please provide a valid response';
    var shouldEndSession = false;
    session.attributes.currentProcessor = processor;
    speechOutput = errorText;
	
	console.log('ServiceHelper.processErrorResponse>: output text is '+speechOutput);
  
    callback(session.attributes, buildSpeechResponse(cardTitle, speechOutput, repromptText, shouldEndSession));
}

function processHelpResponse(helpText, processor, session, callback) {
	//console.log('ServiceHelper.processErrorResponse : CALLED>>> ');
    
    var cardTitle = 'Help Text';

    var repromptText = 'Helpful information for you';
    var shouldEndSession = false;
    session.attributes.currentProcessor = processor;
    speechOutput = helpText;
	
	console.log('ServiceHelper.processHelpResponse>: output text is '+speechOutput);
  
    callback(session.attributes, buildSpeechResponse(cardTitle, speechOutput, repromptText, shouldEndSession));
}

function processMenuResponse(speechOutput, session, callback) {
	console.log('ServiceHelper.processMenuResponse : CALLED>>> ');
	
    var cardTitle = 'Main Menu';

    var repromptText = 'Main Menu Options';
  
    var shouldEndSession = false;
  
    callback(session.attributes, buildSpeechResponse(cardTitle, speechOutput, repromptText, shouldEndSession));
}

function isEmpty(obj) {
    for(var key in obj) {
        if(obj.hasOwnProperty(key))
            return false;
    }
    return true;
}

